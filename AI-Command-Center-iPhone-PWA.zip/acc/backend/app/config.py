import os
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-sol")
DATABASE_PATH = os.getenv("DATABASE_PATH", "./data/ai_dashboard.db")
FRONTEND_ORIGIN = os.getenv("FRONTEND_ORIGIN", "*")
